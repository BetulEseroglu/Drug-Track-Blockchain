import React from 'react';
import QRCode from 'qrcode.react';

const QRCodeGenerator = ({ value }) => {
    console.log("Serial Number:", value.serialNumber, "Decryption Key:", value.decryptionKey);
    return (
        <QRCode value={value.qrContent} size={256} />
    );
};

export default QRCodeGenerator;